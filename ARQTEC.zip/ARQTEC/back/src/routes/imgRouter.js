const { Router } = require('express');

const router = Router();

const { storeImg } = require('../controller/imgController');

router.post('/store/img', storeImg);

module.exports = router;