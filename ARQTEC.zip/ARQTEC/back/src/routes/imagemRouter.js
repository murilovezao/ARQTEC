const { Router } = require('express');

const router = Router();

const { storeImagem } = require('../controller/imagemController');

router.post('/store/imagem', storeImagem);

module.exports = router;