const connection = require('../config/db');
const dotenv = require('dotenv').config();

const fs = require('fs');
const path = require('path');

const uploadPath = path.join(_dirname,'..', 'uploads');

if(!fs.existsSync(uploadPath)) {
    fs.mkdirSync(uploadPath);
}
async function storeImg(request, response) {
    
    if(!request.files) {
        return response.status(400).json({
            sucess: false,
            message: "Você não enviou o arquivo da foto"
        });
    }

    const imagem = request.files.imagem;
    const imagemNome = Date.now() + path.extname(imagemname);   

    file-uploaddd.mv(path.join(uploadPath, file-uploadddNome), (erro) => {
        if(erro) {
            return response.status(400).json({
                sucess: false,
                message: "Erro ao mover o arquivo"
            })
        }
         
        const params = Array(
            imagemNome, 
        )

        const query = "INSERT INTO images(image) VALUES(?)"; 

        connection.query(query, params, (err, results) => {
            if (results) {
                response
                    .status(200)
                    .json({
                        success: true,
                        message: "Sucesso!",
                        data: results
                    })
            } else {
                response
                    .status(400)
                    .json({
                        success: false,
                        message: "Ops, deu problema!",
                        sql: err,
                    })
            }
        })


    });
 
   
}

module.exports = {
    storeImg
}