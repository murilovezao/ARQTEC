use arqtec;

CREATE TABLE usuarios(
	id INT auto_increment primary key,
    email VARCHAR(255),
    senha VARCHAR(255)
);