let uploadImg = document.getElementById('upload');

uploadImg.onclick = async function() {
    let inputImg = document.getElementById('file-upload');
    let dadosInput = new FormData(inputImg);


    const response = await fetch('http://localhost:3001/api/store/vaga', {
        method: 'POST',
        headers: {'Content-type': 'application/json;charset=UTF-8'},
        body: dadosInput
    });
    
    let content = await response.json();
    
    if(content.success) {
        alert('Sucesso!');
    } else {
        alert('Algo deu errado, tente novamente!');
    }
};