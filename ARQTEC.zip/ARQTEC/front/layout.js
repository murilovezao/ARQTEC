let uploadImg = document.getElementById('upload');


document.getElementById('file_imagem').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        const imageData = e.target.result;
        document.getElementById('image-container').innerHTML = '<img src="' + imageData + '" alt="Imagem" class="image">';
        
        document.querySelector('.image').addEventListener('click', function() {
            window.location.href = 'testepg.html?image=' + encodeURIComponent(imageData);
        }); 
    }

// quando clicado, substituir e usar as ferramentas na pg teste pg


    reader.readAsDataURL(file);
});




uploadImg.onclick = async function() {
    let form = document.getElementById('upload_form');
    let dadosForm = new FormData(form);

    const response = await fetch('http://localhost:3001/api/store/imagem', {
        method: 'POST',
        body: dadosForm
    });
    
    let content = await response.json();
    
    if(content.success) {
        alert('Sucesso!');
    } else {
        alert('Algo deu errado, tente novamente!');
    }
};


// TESTE

document.getElementById('close-button').addEventListener('click', function() {
    if (confirm('Você tem certeza de que deseja sair?')) {
        window.history.back();
    }
});
