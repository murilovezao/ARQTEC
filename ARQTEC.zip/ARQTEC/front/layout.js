// Referência ao botão de upload
let uploadImg = document.getElementById('upload');

// Função para salvar imagens no localStorage
function saveImagesToLocalStorage(images) {
    localStorage.setItem('images', JSON.stringify(images));
    // Salva a lista de imagens no localStorage convertendo-a para uma string JSON
}

// Função para carregar imagens do localStorage
function loadImagesFromLocalStorage() {
    const images = localStorage.getItem('images');
    return images ? JSON.parse(images) : [];
    // Carrega a lista de imagens do localStorage e a converte de volta para um objeto JavaScript
    // Se não houver imagens armazenadas, retorna uma lista vazia
}

// Função para renderizar imagens
function renderImages(images) {
    const container = document.getElementById('image-container');
    container.innerHTML = ''; // Limpa imagens anteriores
    
    images.forEach(image => {
        const wrapper = document.createElement('div');
        wrapper.className = 'image-wrapper';
        wrapper.setAttribute('draggable', 'true');

        // Eventos de arrastar e soltar
        wrapper.addEventListener('dragstart', handleDragStart);
        wrapper.addEventListener('dragover', handleDragOver);
        wrapper.addEventListener('dragleave', handleDragLeave);
        wrapper.addEventListener('drop', handleDrop);

        const img = document.createElement('img');
        img.src = image.src;
        img.alt = image.name;
        img.className = 'image';

        const info = document.createElement('div');
        info.className = 'file-info';
        info.innerHTML = `<p>${image.name}</p><p>${(image.size / 1024).toFixed(2)} KB</p>`;

        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-button';
        deleteButton.innerHTML = 'X';
        deleteButton.onclick = function() {
            container.removeChild(wrapper);
            // Remove a imagem do localStorage
            const updatedImages = loadImagesFromLocalStorage().filter(img => img.src !== image.src);
            saveImagesToLocalStorage(updatedImages);
            // Atualiza o localStorage removendo a imagem deletada
        };

        wrapper.appendChild(img);
        wrapper.appendChild(info);
        wrapper.appendChild(deleteButton);
        container.appendChild(wrapper);

        img.addEventListener('click', function() {
            window.location.href = 'testepg.html?image=' + encodeURIComponent(image.src);
        });
        // Define o comportamento ao clicar na imagem, redirecionando para 'testepg.html' com os dados da imagem
    });
}

// Adiciona um listener ao input de arquivo para lidar com mudanças (arquivos selecionados)
document.getElementById('file_imagem').addEventListener('change', function(event) {
    const files = event.target.files; // Obtém os arquivos selecionados
    const container = document.getElementById('image-container'); // Referência ao contêiner de imagens
    container.innerHTML = ''; // Limpa imagens anteriores

    const images = loadImagesFromLocalStorage(); // Carrega imagens existentes do localStorage

    // Para cada arquivo selecionado
    Array.from(files).forEach(file => {
        const reader = new FileReader(); // Cria um FileReader para ler o conteúdo do arquivo

        // Função chamada quando a leitura do arquivo é concluída
        reader.onload = function(e) {
            const imageData = e.target.result; // Dados da imagem
            images.push({ src: imageData, name: file.name, size: file.size });
            // Adiciona a nova imagem à lista de imagens

            const wrapper = document.createElement('div'); // Cria um contêiner para a imagem
            wrapper.className = 'image-wrapper'; // Define a classe do contêiner
            wrapper.setAttribute('draggable', 'true'); // Define o elemento como arrastável

            // Eventos de arrastar e soltar
            wrapper.addEventListener('dragstart', handleDragStart);
            wrapper.addEventListener('dragover', handleDragOver);
            wrapper.addEventListener('dragleave', handleDragLeave);
            wrapper.addEventListener('drop', handleDrop);

            const img = document.createElement('img'); // Cria um elemento de imagem
            img.src = imageData; // Define a fonte da imagem
            img.alt = file.name; // Define o texto alternativo da imagem
            img.className = 'image'; // Define a classe da imagem

            // Cria um elemento para exibir informações do arquivo (nome e tamanho)
            const info = document.createElement('div');
            info.className = 'file-info';
            info.innerHTML = `<p>${file.name}</p><p>${(file.size / 1024).toFixed(2)} KB</p>`;
            
            // Cria um botão de exclusão para remover a imagem
            const deleteButton = document.createElement('button');
            deleteButton.className = 'delete-button';
            deleteButton.innerHTML = 'X';
            // Define o comportamento do botão de exclusão
            deleteButton.onclick = function() {
                container.removeChild(wrapper); // Remove o contêiner da imagem
                // Remove a imagem do localStorage
                const updatedImages = loadImagesFromLocalStorage().filter(img => img.src !== imageData);
                saveImagesToLocalStorage(updatedImages);
                // Atualiza o localStorage removendo a imagem deletada
            };

            // Adiciona a imagem, as informações do arquivo e o botão de exclusão ao contêiner
            wrapper.appendChild(img);
            wrapper.appendChild(info);
            wrapper.appendChild(deleteButton);
            container.appendChild(wrapper);

            // Define o comportamento ao clicar na imagem
            img.addEventListener('click', function() {
                window.location.href = 'testepg.html?image=' + encodeURIComponent(imageData);
            });

            // Salva as imagens no localStorage
            saveImagesToLocalStorage(images);
        };

        reader.readAsDataURL(file); // Lê o arquivo como uma URL de dados
    });
});

// Adiciona um listener ao botão de upload para enviar os arquivos selecionados ao servidor
uploadImg.onclick = async function(event) {
    event.preventDefault(); // Previne o comportamento padrão do botão
    let form = document.getElementById('upload_form'); // Referência ao formulário de upload
    let dadosForm = new FormData(form); // Cria um FormData com os dados do formulário

    // Envia os dados do formulário ao servidor usando fetch
    const response = await fetch('http://localhost:3001/api/store/imagem', {
        method: 'POST',
        body: dadosForm
    });
    
    let content = await response.json(); // Aguarda e analisa a resposta JSON
    
    if(content.success) {
        alert('Sucesso!'); // Exibe uma mensagem de sucesso
    } else {
        alert('Algo deu errado, tente novamente!'); // Exibe uma mensagem de erro
    }
};

// Adiciona um listener ao botão de fechar para retornar à página anterior
document.getElementById('close-button').addEventListener('click', function() {
    if (confirm('Você tem certeza de que deseja sair?')) {
        window.history.back(); // Volta à página anterior
    }
});

// Funções para arrastar e soltar
function handleDragStart(event) {
    event.dataTransfer.setData('text/plain', event.target.id);
    setTimeout(() => {
        event.target.classList.add('hide');
    }, 0);
    // Marca o início do arraste e oculta temporariamente o elemento arrastado
}

function handleDragOver(event) {
    event.preventDefault();
    event.target.classList.add('drag-over');
    // Permite que o elemento seja solto e adiciona uma classe de estilo durante o arraste
}

function handleDragLeave(event) {
    event.target.classList.remove('drag-over');
    // Remove a classe de estilo quando o elemento é arrastado para fora de uma zona de soltar
}

function handleDrop(event) {
    event.preventDefault();
    event.target.classList.remove('drag-over');

    const id = event.dataTransfer.getData('text');
    const draggableElement = document.getElementById(id);
    const dropzone = event.target;

    dropzone.appendChild(draggableElement);
    draggableElement.classList.remove('hide');
    // Solta o elemento arrastado na nova posição e remove a classe de ocultação
}

// Carrega as imagens do localStorage ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    const images = loadImagesFromLocalStorage();
    renderImages(images);
    // Carrega e renderiza as imagens salvas no localStorage ao carregar a página
});
