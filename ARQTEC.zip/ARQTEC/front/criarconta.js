let criarconta = document.getElementById('criarconta');

criarconta.onclick= async function(){
    let email = document.getElementById('email').value;
    let senha = document.getElementById('senha').value;


    let data = {email,senha}

    const response = await fetch('http://localhost:3001/api/store/usuario', {
        method: 'POST',
        headers: {'Content-type': 'application/json;charset=UTF-8'},
        body: JSON.stringify(data)
    });
    
    let content = await response.json();
    
    if(content.success) {
        alert('Sucesso!');
    } else {
        alert('Algo deu errado, tente novamente!');
    }
    
    let reload = await content;
    reload = window.location.href = 'paginadeinicio.html';
}



// SAIR

document.getElementById('close-button').addEventListener('click', function() {
    if (confirm('Você tem certeza de que deseja sair?')) {
        window.history.back();
    }
});
