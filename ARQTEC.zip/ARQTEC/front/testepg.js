// Funções existentes para manipulação do comentário
function toggleComment() {
    var commentContainer = document.getElementById("comment-container");
    if (commentContainer.style.display === "block") {
        commentContainer.style.display = "none";
    } else {
        commentContainer.style.display = "block";
    }
}

function hideComment() {
    document.getElementById("comment-container").style.display = "none";
}

// Funções para manipulação do canvas
let canvasActivated = false;
const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

function toggleCanvas() {
    if (canvasActivated) {
        sendCanvasBack();
        canvasActivated = false;
    } else {
        bringCanvasForward();
        canvasActivated = true;
    }
}

function bringCanvasForward() {
    canvas.style.zIndex = "1";
    canvas.style.pointerEvents = "auto";
}

function sendCanvasBack() {
    canvas.style.zIndex = "-1";
    canvas.style.pointerEvents = "none";
}

let isDrawing = false;
let lastX = 0;
let lastY = 0;

function activateDrawingTool(e) {
    isDrawing = true;
    document.body.style.cursor = "crosshair";
    [lastX, lastY] = [e.clientX, e.clientY];
}

function deactivateDrawingTool() {
    isDrawing = false;
    document.body.style.cursor = "auto";
}

function draw(e) {
    if (!isDrawing) return;

    const newX = e.clientX;
    const newY = e.clientY;

    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(newX, newY);
    ctx.stroke();

    [lastX, lastY] = [newX, newY];
}

document.addEventListener('mousedown', activateDrawingTool);
document.addEventListener('mouseup', deactivateDrawingTool);
document.addEventListener('mousemove', draw);

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});

window.addEventListener('DOMContentLoaded', () => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const imageData = urlParams.get('image');

    if (imageData) {
        document.querySelector('.image').setAttribute('src', decodeURIComponent(imageData));
    }
});

