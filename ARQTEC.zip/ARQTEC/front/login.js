

// let botao = document.getElementById("acessarbotao");

// botao.addEventListener("click", function() {
//     window.location ="paginainicio.html";
// })